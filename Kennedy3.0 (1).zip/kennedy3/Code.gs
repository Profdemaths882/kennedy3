/**
 * KENNEDY 3.0 · serveur Google Apps Script
 * CEM J.F. Kennedy · Formation des enseignants · IA et applications éducatives
 *
 * Ce script range toutes les données de l'application dans la feuille Google Sheets
 * à laquelle il est attaché : comptes des profs, avancement (étapes, missions) et livrables.
 * Les auto-évaluations d'entrée et de sortie restent dans les formulaires Google Forms déjà créés.
 *
 * Installation (une seule fois) :
 *   1. Créer une feuille Google Sheets « Kennedy 3.0 – données ».
 *   2. Extensions › Apps Script › coller ce code › Enregistrer.
 *   3. Changer CODE_FORMATEUR_INITIAL ci-dessous, puis exécuter la fonction installer › Autoriser.
 *   4. Déployer › Nouveau déploiement › Type : Application Web
 *        Exécuter en tant que : Moi · Qui a accès : Tout le monde › Déployer.
 *   5. Copier l'URL de l'application Web (…/exec) dans index.html (constante API_URL).
 *
 * Après une modification de ce code : Déployer › Gérer les déploiements › Modifier › Nouvelle version.
 */

const CODE_FORMATEUR_INITIAL = 'KENNEDY2026';   // à changer avant d'exécuter installer()

const FEUILLES = {
  Profs:       ['Pseudo', 'Empreinte', 'Jeton', 'Prénom', 'Nom', 'Cellule', 'Disciplines', 'Niveaux', 'Référent', 'Inscrit le', 'Vu le'],
  Avancement:  ['Pseudo', 'Cellule', 'Clé', 'Valeur', 'Date'],
  Livrables:   ['Pseudo', 'Cellule', 'Type', 'Valeur', 'Date']
};

/* ---------- installation ---------- */

function installer() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(FEUILLES).forEach(function (nom) {
    let sh = ss.getSheetByName(nom);
    if (!sh) sh = ss.insertSheet(nom);
    if (sh.getLastRow() === 0) {
      sh.appendRow(FEUILLES[nom]);
      sh.getRange(1, 1, 1, FEUILLES[nom].length).setFontWeight('bold').setBackground('#0F2552').setFontColor('#FFFFFF');
      sh.setFrozenRows(1);
    }
  });
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('CODE_FORMATEUR')) props.setProperty('CODE_FORMATEUR', CODE_FORMATEUR_INITIAL);
  Logger.log('Installation terminée. Code formateur : ' + props.getProperty('CODE_FORMATEUR'));
}

function changerCodeFormateur() {   // modifier la valeur puis exécuter
  PropertiesService.getScriptProperties().setProperty('CODE_FORMATEUR', 'NOUVEAU_CODE_ICI');
}

/* ---------- point d'entrée ---------- */

function doGet() {
  return json_({ ok: true, app: 'Kennedy 3.0', message: 'Serveur en ligne.' });
}

function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, erreur: 'Requête illisible.' }); }
  const actions = { inscrire: inscrire_, connexion: connexion_, sauver: sauver_,
                    livrable: livrable_, formateur: formateur_, cellule: cellule_ };
  const f = actions[req.action];
  if (!f) return json_({ ok: false, erreur: 'Action inconnue.' });
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    return json_(f(req));
  } catch (err) {
    return json_({ ok: false, erreur: 'Serveur occupé, réessaie dans un instant.' });
  } finally {
    try { lock.releaseLock(); } catch (e2) {}
  }
}

/* ---------- comptes ---------- */

function inscrire_(r) {
  const pseudo = normPseudo_(r.pseudo);
  if (!/^[a-z0-9._-]{3,20}$/.test(pseudo)) return { ok: false, erreur: 'Pseudo invalide : 3 à 20 lettres, chiffres, point ou tiret.' };
  if (!/^\d{4}$/.test(String(r.pin || ''))) return { ok: false, erreur: 'Le code secret doit avoir 4 chiffres.' };
  if (!r.prenom || !r.nom || !r.cellule) return { ok: false, erreur: 'Prénom, nom et cellule sont obligatoires.' };
  const sh = feuille_('Profs');
  if (ligneProf_(sh, pseudo)) return { ok: false, pris: true, erreur: 'Ce pseudo est déjà pris.' };
  const jeton = Utilities.getUuid();
  sh.appendRow([pseudo, empreinte_(pseudo, r.pin), jeton, txt_(r.prenom, 40), txt_(r.nom, 40), txt_(r.cellule, 40),
                txt_(r.disciplines, 120), txt_(r.niveaux, 40), r.referent ? 'Oui' : '', new Date(), new Date()]);
  return { ok: true, jeton: jeton, profil: profil_(sh, ligneProf_(sh, pseudo)) };
}

function connexion_(r) {
  const pseudo = normPseudo_(r.pseudo);
  const sh = feuille_('Profs');
  const n = ligneProf_(sh, pseudo);
  if (!n) return { ok: false, erreur: 'Pseudo inconnu.' };
  const row = sh.getRange(n, 1, 1, FEUILLES.Profs.length).getValues()[0];
  if (row[1] !== empreinte_(pseudo, r.pin)) return { ok: false, erreur: 'Code secret incorrect.' };
  sh.getRange(n, 11).setValue(new Date());
  return { ok: true, jeton: row[2], profil: profil_(sh, n), donnees: donneesProf_(pseudo) };
}

function verifier_(r) {
  const pseudo = normPseudo_(r.pseudo);
  const sh = feuille_('Profs');
  const n = ligneProf_(sh, pseudo);
  if (!n) return null;
  const row = sh.getRange(n, 1, 1, FEUILLES.Profs.length).getValues()[0];
  if (!r.jeton || row[2] !== r.jeton) return null;
  sh.getRange(n, 11).setValue(new Date());
  return { pseudo: pseudo, cellule: row[5], ligne: n };
}

/* ---------- écritures ---------- */

function sauver_(r) {   // r.items = [{cle, valeur}]
  const p = verifier_(r);
  if (!p) return { ok: false, session: true, erreur: 'Session expirée : reconnecte-toi.' };
  (r.items || []).slice(0, 80).forEach(function (it) {
    upsert_('Avancement', p.pseudo, String(it.cle).slice(0, 60), [p.pseudo, p.cellule, String(it.cle).slice(0, 60), txt_(it.valeur, 2000), new Date()], 3);
  });
  if (r.referent !== undefined) feuille_('Profs').getRange(p.ligne, 9).setValue(r.referent ? 'Oui' : '');
  return { ok: true };
}

function livrable_(r) {
  const p = verifier_(r);
  if (!p) return { ok: false, session: true, erreur: 'Session expirée : reconnecte-toi.' };
  upsert_('Livrables', p.pseudo, String(r.type).slice(0, 40), [p.pseudo, p.cellule, String(r.type).slice(0, 40), txt_(r.valeur, 5000), new Date()], 3);
  return { ok: true };
}

/* ---------- lectures ---------- */

function cellule_(r) {   // livrables des collègues de la même cellule
  const p = verifier_(r);
  if (!p) return { ok: false, session: true, erreur: 'Session expirée : reconnecte-toi.' };
  const profs = lignes_('Profs').filter(function (x) { return x[5] === p.cellule; })
    .map(function (x) { return { pseudo: x[0], prenom: x[3], nom: x[4], referent: x[8] === 'Oui' }; });
  const livrables = lignes_('Livrables').filter(function (x) { return x[1] === p.cellule; })
    .map(function (x) { return { pseudo: x[0], type: x[2], valeur: x[3] }; });
  return { ok: true, profs: profs, livrables: livrables };
}

function formateur_(r) {
  const code = PropertiesService.getScriptProperties().getProperty('CODE_FORMATEUR');
  if (!code || String(r.code || '') !== code) return { ok: false, erreur: 'Code formateur incorrect.' };
  return {
    ok: true,
    profs: lignes_('Profs').map(function (x) {
      return { pseudo: x[0], prenom: x[3], nom: x[4], cellule: x[5], disciplines: x[6], niveaux: x[7],
               referent: x[8] === 'Oui', inscrit: date_(x[9]), vu: date_(x[10]) };
    }),
    avancement: lignes_('Avancement').map(function (x) { return { pseudo: x[0], cle: x[2], valeur: x[3] }; }),
    livrables: lignes_('Livrables').map(function (x) { return { pseudo: x[0], cellule: x[1], type: x[2], valeur: x[3], date: date_(x[4]) }; })
  };
}

function donneesProf_(pseudo) {
  const av = {};
  lignes_('Avancement').forEach(function (x) { if (x[0] === pseudo) av[x[2]] = x[3]; });
  const li = {};
  lignes_('Livrables').forEach(function (x) { if (x[0] === pseudo) li[x[2]] = x[3]; });
  return { avancement: av, livrables: li };
}

/* ---------- outils ---------- */

function feuille_(nom) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(nom);
  if (!sh) { installer(); sh = ss.getSheetByName(nom); }
  return sh;
}

function lignes_(nom) {
  const sh = feuille_(nom);
  const n = sh.getLastRow();
  if (n < 2) return [];
  return sh.getRange(2, 1, n - 1, FEUILLES[nom].length).getValues();
}

function ligneProf_(sh, pseudo) {
  const n = sh.getLastRow();
  if (n < 2) return 0;
  const col = sh.getRange(2, 1, n - 1, 1).getValues();
  for (let i = 0; i < col.length; i++) if (String(col[i][0]) === pseudo) return i + 2;
  return 0;
}

function upsert_(nom, pseudo, cle, ligne, colCle) {   // remplace la ligne (pseudo, clé) ou l'ajoute
  const sh = feuille_(nom);
  const n = sh.getLastRow();
  if (n >= 2) {
    const v = sh.getRange(2, 1, n - 1, colCle).getValues();
    for (let i = 0; i < v.length; i++) {
      if (String(v[i][0]) === pseudo && String(v[i][colCle - 1]) === cle) {
        sh.getRange(i + 2, 1, 1, ligne.length).setValues([ligne]);
        return;
      }
    }
  }
  sh.appendRow(ligne);
}

function profil_(sh, n) {
  const x = sh.getRange(n, 1, 1, FEUILLES.Profs.length).getValues()[0];
  return { pseudo: x[0], prenom: x[3], nom: x[4], cellule: x[5], disciplines: x[6], niveaux: x[7], referent: x[8] === 'Oui' };
}

function empreinte_(pseudo, pin) {
  const b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'k3|' + pseudo + '|' + pin, Utilities.Charset.UTF_8);
  return b.map(function (x) { return ((x + 256) % 256).toString(16).padStart(2, '0'); }).join('');
}

function normPseudo_(p) { return String(p || '').trim().toLowerCase().replace(/\s+/g, ''); }
function txt_(v, max) { return String(v === undefined || v === null ? '' : v).slice(0, max); }
function parse_(s, d) { try { return JSON.parse(s); } catch (e) { return d; } }
function date_(d) { return d instanceof Date ? Utilities.formatDate(d, 'Africa/Dakar', 'dd/MM HH:mm') : String(d || ''); }
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
